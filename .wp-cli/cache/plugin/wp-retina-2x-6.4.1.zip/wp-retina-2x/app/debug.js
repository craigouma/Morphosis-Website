/* eslint-disable */

window.devicePixelRatio = 2;